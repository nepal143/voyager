# Voyager 
Run command for backend  
deno run -A src/app.ts
<br/>
Run command for login  
deno run --allow-read=./ --allow-write=./localdb --allow-net=:8000 --watch server.ts  


Check point 1 update 12:33;
